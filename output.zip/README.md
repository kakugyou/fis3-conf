#Fis3 Conf 常用设置
- 设置项目属性
- 内置语法
- 预处理
- 文件指纹
- 资源压缩
- CSS Sprite
- 内容嵌入
- 资源定位
- 资源合并
- 目录设置
- 打包 需要fis3-deploy-zip支持


##Fis3使用说明

1.安装fis3 参考 http://fis.baidu.com/fis3/docs/beginning/intro.html

  npm install -g fis3

  安装fis3常用插件
  npm install -g fis-parser-less
  npm install -g fis3-postpackager-loader


2.npm install && bower install

3.执行fis3 release -wl 命令编译并生成预览文件到output/


4 安装puer静态资源服务器  npm install -g puer

5 cd output 目录 执行puer 命令



##NPM Scripts使用说明